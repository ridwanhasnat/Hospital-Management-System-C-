﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    class User
    {
        public User() { }
        Database d1 = new Database();
        public string adminFirstName;
        public string adminLastName;
        public string adminUserName;
        public string adminAge;
        public string adminCellno;
        public string adminBloodGroup;
        public string adminGender;
        public string adminEmergencyContact;
        public string adminPost;
        public string docID;
        public string docFirstName;
        public string docLastName;
        public string docUserName;
        public string docGender;
        public string docBloodGroup;
        public string docPost;
        public string docEducation;
        public string docCellno;
        public string docAge;
        public string docEmergencyContact;
        public string docPassword;
        public string staffFirstName;
        public string staffLastName;
        public string staffUserName;
        public string staffGender;
        public string staffAge;
        public string staffCellno;
        public string staffEmergencyContact;
        public string staffBloodGroup;
        public string staffPost;
        public string staffID;
        public string staffPassword;
        public int type;



        //property of every variable below -->
        public string AdminFirstName
        {
            set { this.adminFirstName = value; }
            get { return this.adminFirstName; }
        }

        public string AdminLastName
        {
            set { this.adminLastName = value; }
            get { return this.adminLastName; }
        }

        public string AdminUserName
        {
            set { this.adminUserName = value; }
            get { return this.adminUserName; }
        }
        public string AdminAge
        {
            set { this.adminAge = value; }
            get { return this.adminAge; }
        }
        public string AdminBloodGroup
        {
            set { this.adminBloodGroup = value; }
            get { return this.adminBloodGroup; }
        }
        public string AdminEmergencyContact
        {
            set { this.adminEmergencyContact = value; }
            get { return this.adminEmergencyContact; }
        }
        public string AdminPost
        {
            set { this.adminPost = value; }
            get { return this.adminPost; }
        }
        public string AdminCellno
        {
            set { this.adminCellno = value; }
            get { return this.adminCellno; }
        }
        public string AdminGender
        {
            set { this.adminGender = value; }
            get { return this.adminGender; }
        }

         public string DocID
        {
            set { this.docID = value; }
            get { return this.docID; }
        }
        public string DocFirstName
        {
            set { this.docFirstName = value; }
            get { return this.docFirstName; }
        }

        public string DocLastName
        {
            set { this.docLastName = value; }
            get { return this.docLastName; }
        }

        public string DocUserName
        {
            set { this.docUserName = value; }
            get { return this.docUserName; }
        }
        public string DocAge
        {
            set { this.docAge = value; }
            get { return this.docAge; }
        }
        public string DocBloodGroup
        {
            set { this.docBloodGroup = value; }
            get { return this.docBloodGroup; }
        }
        public string DocEmergencyContact
        {
            set { this.docEmergencyContact = value; }
            get { return this.docEmergencyContact; }
        }
        public string DocEducation
        {
            set { this.docEducation = value; }
            get { return this.docEducation; }
        }
        public string DocCellno
        {
            set { this.docCellno = value; }
            get { return this.docCellno; }
        }
        public string DocGender
        {
            set { this.docGender = value; }
            get { return this.docGender; }
        }
        public string DocPost
        {
            set { this.docPost = value; }
            get { return this.docPost; }
        }
         public string DocPassword
        {
            set { this.docPassword = value; }
            get { return this.docPassword; }
        }

        public string StaffFirstName
        {
            set { this.staffFirstName = value; }
            get { return this.staffFirstName; }
        }

        public string StaffLastName
        {
            set { this.staffLastName = value; }
            get { return this.staffLastName; }
        }

        public string StaffUserName
        {
            set { this.staffUserName = value; }
            get { return this.staffUserName; }
        }
        public string StaffGender
        {
            set { this.staffGender = value; }
            get { return this.staffGender; }
        }
        public string StaffCellno
        {
            set { this.staffCellno = value; }
            get { return this.staffCellno; }
        }
        public string StaffEmergencyContact
        {
            set { this.staffEmergencyContact = value; }
            get { return this.staffEmergencyContact; }
        }
        public string StaffBloodGroup
        {
            set { this.staffBloodGroup = value; }
            get { return this.staffBloodGroup; }
        }
        public string StaffPost
        {
            set { this.staffPost = value; }
            get { return this.staffPost; }
        }
        public string StaffAge
        {
            set { this.staffAge = value; }
            get { return this.staffAge; }
        }

        public string StaffID
        {
            set { this.staffID = value; }
            get { return this.staffID; }
        }

        public string StaffPassword
        {
            set { this.staffPassword = value; }
            get { return this.staffPassword; }
        }

         public int Type
        {
            set { this.type = value; }
            get { return this.type; }
        }

        public int logIn(string un, string pw)
        {
            //try
            //{


            type = d1.getType(un, pw);
            return type;



            // }

            // catch { throw ; }   

        }
        public string getDocFirstName(string un)
        {
            try
            {
                DocFirstName = d1.getFname(un);
                return DocFirstName;
            }
            catch
            {
                throw;
            }
        }

        public string getDocLastName(string un)
        {
            try
            {
                DocLastName = d1.getLname(un);
                return DocLastName;
            }
            catch
            {
                throw;
            }
        }

        public string getDocUserName(string un)
        {
            try
            {

                return d1.getUname(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocGender(string un)
        {
            try
            {

                return d1.getGndr(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocAge(string un)
        {
            try
            {

                return d1.getAg(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocCellPhone(string un)
        {
            try
            {

                return d1.getCell(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocPost(string un)
        {
            try
            {

                return d1.getPost(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocBloodgroup(string un)
        {
            try
            {

                return d1.getBG(un);
            }
            catch
            {
                throw;
            }
        }

        public string getDocEducation(string un)
        {
            try
            {

                return d1.getDocedu(un);
            }
            catch
            {
                throw;
            }
        }
        public string getDocEmergencyContact(string un)
        {
            try
            {

                return d1.getEC(un);
            }
            catch
            {
                throw;
            }
        }
        public DataTable getPatientList() {

            try
            {
                return d1.getPlist();
            }
            catch
            {
                throw;
            }
        
        }
        public void addDoctor(string id, string fn, string ln, string un, string ag, string gen, string bg, string cell, string docedu, string post, string pass, string ec, int type)
        {

            d1.addDoc(id,fn,ln, un,ag,gen,bg, cell,docedu,post,pass,ec,type);
        
        }

        public void removeDoctor(string Id) { d1.removeDoc(Id); }

        public void addStaff(string id, string fn, string ln, string un, string ag, string gen, string bg, string cell, string post, string pass, string ec, int type)
        {

            d1.addStf(id,fn,ln,un,ag,gen,bg,cell,post,pass,ec,type);
        
        
        }
        public void removeStaff(string Id) { d1.removeStf(Id); }

    }
}
        /*
         using System; using System.Collections.Generic; using System.Data; using WindowsFormsApplication1.DAL;
 
namespace WindowsFormsApplication1.BLL
{
    public class PersonBLL
    {
        public DataTable GetPersons()
        {
            try
            {
                PersonDAL objdal = new PersonDAL();
                return objdal.Read();
            }
            catch
            {
                throw;
            }
        }
        public DataTable GetPersons(Int16 ID)
        {
            try
            {
                PersonDAL objdal = new PersonDAL();
                return objdal.Read(ID);
            }
            catch
            {
                throw;
            }
        }
       
    }
}
        */
   



