﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class AddStaff : Form
    {
        public AddStaff()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StaffManagement sm = new StaffManagement();
            sm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            User u = new User();

            u.StaffFirstName = textBox1.Text;
            u.StaffLastName = textBox2.Text;
            u.StaffAge = textBox3.Text;
            u.StaffBloodGroup = textBox6.Text;
            u.StaffID = textBox7.Text;
            u.StaffCellno = textBox8.Text;
            u.StaffPost = textBox10.Text;
            u.StaffUserName = textBox11.Text;
            u.StaffPassword = textBox4.Text;
            u.StaffEmergencyContact = textBox5.Text;
            u.Type = Convert.ToInt32(textBox12.Text);
            if (radioButton1.Checked == true) { u.StaffGender = "Male"; }
            if (radioButton2.Checked == true) { u.StaffGender = "Female"; }
            u.addStaff(u.StaffID, u.StaffFirstName, u.StaffLastName, u.StaffUserName, u.StaffAge, u.StaffGender, u.StaffBloodGroup, u.StaffCellno, u.StaffPost, u.StaffPassword, u.StaffEmergencyContact, u.Type);
            MessageBox.Show("Staff Added");
        }
    }
}
