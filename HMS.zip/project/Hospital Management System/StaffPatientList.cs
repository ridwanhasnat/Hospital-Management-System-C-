﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public delegate void MydelSPL();
    public partial class StaffPatientList : Form
    {
        public StaffPatientList()
        {
            InitializeComponent();
        }

        private void StaffPatientList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hospitalDatabaseDataSet.PatientsTable' table. You can move, or remove it, as needed.
            //this.patientsTableTableAdapter.Fill(this.hospitalDatabaseDataSet.PatientsTable);
            Database db = new Database();
            dataGridView1.DataSource = db.getPlist();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Staff s1 = new Staff();
            MydelSPL d = s1.Show;
            d.Invoke();
            this.Hide(); 
        }
    }
}
