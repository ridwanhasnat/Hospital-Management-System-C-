﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    class Database
    {


      
        SqlConnection con = new SqlConnection(Hospital_Management_System.Properties.Settings.Default.HospitalDatabaseConnectionString);
        DataTable dt = new DataTable();


        public int getType(string un,string pw)
        {

            string query = "select Type from UserTable where Username ='" + un + "' AND Password ='" + pw  + "'";

            con.Open();

            SqlCommand cmd = new SqlCommand(query, con);
           
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
               // int tp = Convert.ToInt32(dt);
                con.Close();

                return Convert.ToInt32(dt.Rows[0].ItemArray[0]);
                

            }
            catch{Login l = new Login();
            l.Error();
            throw;
            }
            
            
            
        }

          public  string getFname(string un) 
        {
            string query = "select FirstName from UserTable where Username='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);

            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                con.Close();
                return dt.Rows[0].ItemArray[0].ToString();

            }

            catch { throw; }
          }

         public  string getLname(string un) 
        {
            string query = "select LastName from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                con.Close();
                return dt.Rows[0]["LastName"].ToString();
            
       }
            catch{throw;}
          }

         public  string getUname(string un) 
        {
             
            string query = "select Username from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getGndr(string un) 
        {
            string query = "select Gender from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getAg(string un) 
        {
            string query = "select Age from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getCell(string un) 
        {
            string query = "select CellPhone from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getPost(string un) 
        {
            string query = "select Post from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getBG(string un) 
        {
            string query = "select BloodGroup from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getDocedu(string un) 
        {
            string query = "select Education from UserTable where Username='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }

         public string getEC(string un) 
        {
            string query = "select EmergencyContact from UserTable where Username ='" + un + "'";

            con.Open();
            
            SqlCommand cmd = new SqlCommand(query, con);
            try{
                SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            con.Close();
            return dt.Rows[0].ItemArray[0].ToString();
       }
            catch{throw;}
          }
         public DataTable getPlist()
         {

            con.ConnectionString=Hospital_Management_System.Properties.Settings.Default.HospitalDatabaseConnectionString;
             if (ConnectionState.Closed == con.State)
                 con.Open();
             SqlCommand cmd = new SqlCommand("select * from PatientsTable", con);
             try
             {
                 SqlDataReader rd = cmd.ExecuteReader();
                 dt.Load(rd);
                 return dt;


             }

             catch { throw; }
         }

         public void addDoc(string id, string fn, string ln, string un, string ag, string gen, string bg, string cell, string docedu, string post, string pass, string ec,int type)
         {
             string query = "insert into UserTable(Id,FirstName,LastName,Username,Gender,Age,CellPhone,BloodGroup,EmergencyContact,Post,Education,Password,Type) values('" + id + "','" + fn + "','" + ln + "','" + un + "','" + gen + "','" + ag + "','" + cell + "','" + bg + "','" + ec + "','" + post + "','" + docedu + "','" + pass + "','" + type + "')";
             con.Open();

             SqlCommand cmd = new SqlCommand(query, con);
             cmd.ExecuteNonQuery();

             con.Close();
         }

         public void removeDoc(string ID) {

             string query = "delete from UserTable where Id='" + ID + "'";

             con.Open();

             SqlCommand cmd = new SqlCommand(query, con);
             cmd.ExecuteNonQuery();

             con.Close();
         
         }
         public void addStf(string id, string fn, string ln, string un, string ag, string gen, string bg, string cell, string post, string pass, string ec, int type)
         {

             string query = "insert into UserTable(Id,FirstName,LastName,Username,Gender,Age,CellPhone,BloodGroup,EmergencyContact,Post,Password,Type) values('" + id + "','" + fn + "','" + ln + "','" + un + "','" + gen + "','" + ag + "','" + cell + "','" + bg + "','" + ec + "','" + post + "','" + pass + "','" + type + "')";
             con.Open();

             SqlCommand cmd = new SqlCommand(query, con);
             cmd.ExecuteNonQuery();

             con.Close();
         }
         public void removeStf(string ID) { 
         
             string query = "delete from UserTable where Id='" + ID + "'";

             con.Open();

             SqlCommand cmd = new SqlCommand(query, con);
             cmd.ExecuteNonQuery();

             con.Close();
         
         }
        
        }
}




/*
   using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
namespace WindowsFormsApplication1.DAL
    public class PersonDAL
{
public string ConString = 
  "Data Source=SOURAV-PC\\SQL_INSTANCE;Initial Catalog=test;Integrated Security=True";
SqlConnection con = new SqlConnection();
DataTable dt = new DataTable();
public DataTable Read()
{
  con.ConnectionString = ConString;
  if (ConnectionState.Closed == con.State)
      con.Open();
  SqlCommand cmd = new SqlCommand("select * from Person",con);
  try
  {
      SqlDataReader rd = cmd.ExecuteReader();
      dt.Load(rd);
      return dt;
  }
  catch
  {
      throw;
  }
}
public DataTable Read(Int16 Id)
{
  con.ConnectionString = ConString;
  if (ConnectionState.Closed == con.State)
      con.Open();
  SqlCommand cmd = new SqlCommand("select * from Person where ID= "+ Id +"", con);
  try
  {
      SqlDataReader rd = cmd.ExecuteReader();
      dt.Load(rd);
      return dt;
  }
  catch
  {
      throw;
  }
}
}
}
   */
