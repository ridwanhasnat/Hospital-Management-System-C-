﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class AddDoctor : Form
    {
        public AddDoctor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DoctorManagement dm = new DoctorManagement();
            dm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            User u = new User();
          
            u.DocFirstName= textBox1.Text;
            u.DocLastName = textBox2.Text;
            u.DocAge = textBox3.Text;
            u.DocBloodGroup = textBox6.Text;
            u.DocID = textBox7.Text;
            u.DocCellno = textBox8.Text;
            u.DocEducation = textBox9.Text;
            u.DocPost = textBox10.Text;
            u.DocUserName = textBox11.Text;
            u.DocPassword = textBox4.Text;
            u.DocEmergencyContact = textBox5.Text;
            u.Type = Convert.ToInt32(textBox12.Text);
            if (radioButton1.Checked == true) { u.DocGender = "Male"; }
            if (radioButton2.Checked == true) { u.DocGender = "Female"; }
            u.addDoctor(u.DocID, u.DocFirstName, u.DocLastName, u.DocUserName, u.DocAge, u.DocGender, u.DocBloodGroup, u.DocCellno, u.DocEducation, u.DocPost, u.DocPassword, u.DocEmergencyContact, u.Type);
            MessageBox.Show("Doctor Added");


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddDoctor_Load(object sender, EventArgs e)
        {

        }
    }
}
