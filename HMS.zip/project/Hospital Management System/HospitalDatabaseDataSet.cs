﻿namespace Hospital_Management_System {
    
    
    public partial class HospitalDatabaseDataSet {
    }
}
